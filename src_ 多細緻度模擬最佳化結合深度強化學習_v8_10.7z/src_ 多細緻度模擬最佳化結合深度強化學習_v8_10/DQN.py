import random
import torch.nn as nn
import torch.nn.functional as F
import torch
import numpy as np
from collections import deque
from scipy.stats import entropy
from strategies import reposition_rules
import utils.astar as astar
np.set_printoptions(threshold=np.inf)

class Net(nn.Module):
    def __init__(self, num_inputs=9, num_actions=4):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(num_inputs, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, num_actions)
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)

class SumTree:
    write = 0
    def __init__(self, capacity):
        self.capacity = capacity
        self.tree = np.zeros(2 * capacity - 1)
        self.data = np.zeros(capacity, dtype=object)
        self.n_entries = 0
    def _propagate(self, idx, change):
        parent = (idx - 1) // 2
        self.tree[parent] += change
        if parent != 0:
            self._propagate(parent, change)
    def _retrieve(self, idx, s):
        left = 2 * idx + 1
        right = left + 1
        if left >= len(self.tree):
            return idx
        if s <= self.tree[left]:
            return self._retrieve(left, s)
        else:
            return self._retrieve(right, s - self.tree[left])
    def total(self):
        return self.tree[0]
    def add(self, p, data):
        idx = self.write + self.capacity - 1
        self.data[self.write] = data
        self.update(idx, p)
        self.write = (self.write + 1) % self.capacity
        self.n_entries = min(self.n_entries + 1, self.capacity)
    def update(self, idx, p):
        change = p - self.tree[idx]
        self.tree[idx] = p
        self._propagate(idx, change)
    def get(self, s):
        idx = self._retrieve(0, s)
        dataIdx = idx - self.capacity + 1
        return (idx, self.tree[idx], self.data[dataIdx])

class Memory:
    e = 0.01
    a = 0.6
    beta = 0.4
    beta_increment_per_sampling = 0.001
    def __init__(self, capacity):
        self.tree = SumTree(capacity)
    def _get_priority(self, error):
        return (np.abs(error) + self.e) ** self.a
    def add(self, error, sample):
        p = self._get_priority(error)
        self.tree.add(p, sample)
    def sample(self, n):
        batch, idxs, priorities = [], [], []
        segment = self.tree.total() / n
        self.beta = min(1., self.beta + self.beta_increment_per_sampling)
        for i in range(n):
            s = random.uniform(segment * i, segment * (i + 1))
            idx, p, data = self.tree.get(s)
            priorities.append(p)
            batch.append(data)
            idxs.append(idx)
        sampling_probabilities = priorities / self.tree.total()
        is_weight = np.power(self.tree.n_entries * sampling_probabilities, -self.beta)
        is_weight /= is_weight.max()
        return batch, idxs, is_weight
    def update(self, idx, error):
        p = self._get_priority(error)
        self.tree.update(idx, p)

def manhattan_distance(pos1, pos2):
    return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

class Agent:
    def __init__(self, policy_net, target_net):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.policy_network = policy_net.to(self.device)
        self.target_network = target_net.to(self.device)
        self.update_target()
        self.epsilon_start = 1.0
        self.epsilon = self.epsilon_start
        self.epsilon_end = 0.05
        self.epsilon_decay = 15000
        self.current_step = 0
        self.memory_size = 200000
        self.start_training_info_number = 500
        self.learn_step_counter = 0
        self.TARGET_REPLACE_ITER = 1000
        self.batch_size = 128
        self.GAMMA = 0.97
        self.memory = Memory(self.memory_size)
        self.lr_start = 0.001
        self.lr_end = 0.00005
        self.lr = self.lr_start
        self.lr_count = 0
        self.epsilon_count = 0
        self.optimizer = torch.optim.Adam(self.policy_network.parameters(), lr=1e-4)
        self.loss_function = torch.nn.SmoothL1Loss()
        self.distance_log = []
        self.loss_value = []
        self.training_rewards = []
        self.action_count = {i:0 for i in range(4)}
        self.tau = 1.0

    def update_target(self):
        self.target_network.load_state_dict(self.policy_network.state_dict())

    def log_training_distance(self, dist, total_tasks=None):
        dynamic_threshold = max(20000, total_tasks * 15) if total_tasks else 99999999
        if not hasattr(self, 'distance_raw_log'):
            self.distance_raw_log = []
        # 記錄每一回合的距離
        if dist > 0 and dist < dynamic_threshold:
            self.distance_raw_log.append(dist)
            # 同步最佳收斂
            if not self.distance_log:
                self.distance_log.append(dist)
            else:
                best_so_far = min(self.distance_log[-1], dist)
                self.distance_log.append(best_so_far)

    def log_episode_reward(self, reward, is_valid=True):
        if is_valid:
            self.training_rewards.append(reward)

    def choose_action(self, state, train=True):
        self.current_step += 1
        epsilon = self.epsilon_end + (self.epsilon_start - self.epsilon_end) * \
            np.exp(-1. * self.current_step / self.epsilon_decay)
        state = torch.tensor(state, dtype=torch.float).unsqueeze(0).to(self.device)
        if train and np.random.rand() < epsilon:
            action = np.random.randint(0, 4)
        else:
            with torch.no_grad():
                q_values = self.policy_network(state).cpu().numpy().flatten()
                action = np.argmax(q_values)
        self.action_count[action] += 1
        return action

    def apply_action(self, pod, action, layout):
        actions = [reposition_rules.reposition_nearest, reposition_rules.reposition_cache, reposition_rules.reposition_utility]
        pos = actions[action](pod, layout) if action in [0,1,2] else (pod.storage_station.x_position, pod.storage_station.y_position)
        layout.zone_usage[pos] = layout.zone_usage.get(pos, 0) + 1
        return pos

    def get_state(self, pod, layout):
        max_dist = layout.scene_x_width + layout.scene_y_width
        total_pods = max(len(layout.pod_list), 1)

        # === 原始特徵 + 正規化改寫 ===
        f1 = len(layout.task_list) / 100.0                        # 任務負載程度
        f2 = 1.0 if getattr(pod, 'picked', False) else 0.0       # 是否已被處理
        f3 = len(reposition_rules.get_available_storage_stations(layout)) / total_pods

        # === 距離計算類特徵 ===
        pod_pos = (pod.storage_station.x_position, pod.storage_station.y_position)
        ps_pos = (layout.picking_station_list[0].x_position, layout.picking_station_list[0].y_position)

        try:
            finder = astar.FindPathAstar(layout.to_matrix(), pod_pos, ps_pos)
            found, path, *_ = finder.run_astar_method()
            dist = len(path) if found else max_dist
        except:
            dist = max_dist
        f4 = dist / max_dist                                     # 到揀貨站的標準化距離

        # === 環境資訊類 ===
        f5 = self.min_agv_distance(pod, layout) / max_dist       # AGV 與此 pod 的最小距離
        f6 = min(self.compute_future_overlap(pod, layout), 1.0)  # 未來任務重疊度
        f7 = self.compute_local_density(pod_pos, layout, radius=2) # 壅塞度
        f8 = layout.pod_usage_counter.get(pod.pod_id, 0) / 10.0 if hasattr(layout, 'pod_usage_counter') else 0.0
        move_history = layout.pod_move_history.get(pod.pod_id, [dist])
        f9 = np.mean(move_history) / max_dist                    # 歷史平均移動成本

        return np.array([f1, f2, f3, f4, f5, f6, f7, f8, f9], dtype=np.float32)

    def compute_reward(self, pod, new_position, layout, action=None):
        ps_pos = (layout.picking_station_list[0].x_position, layout.picking_station_list[0].y_position)
        old_pos = (pod.storage_station.x_position, pod.storage_station.y_position)
        max_dist = layout.scene_x_width + layout.scene_y_width

        # 距離改善（越靠近越好）
        dist_gain = max(manhattan_distance(old_pos, ps_pos) - manhattan_distance(new_position, ps_pos), 0)
        r_combo = 1.0 * (dist_gain / max_dist)

        # 壅塞處罰（附近AGV越多，懲罰越高）
        congestion = self.compute_local_density(new_position, layout)
        r_congestion = -3.0 * min(congestion, 1.0)

        # 未來需求重疊度
        pod_future_demand = self.compute_future_overlap(pod, layout)  # 已歸一化 0~1
        r_future = 8.0 * pod_future_demand

        # ===【策略特定獎懲】===
        # 若「需求極低的料架」被放在最近（Nearest）→ 懲罰
        if action == 0 and pod_future_demand < 0.2:
            r_combo -= 3.5
        # 若「需求很高的料架」被放Cache或Utility → 獎勵（引導更平均分布）
        if action == 1 and pod_future_demand > 0.5:
            r_combo += 3.0
        if action == 2 and pod_future_demand > 0.4:
            r_combo += 2.0

        # ===【策略熵：鼓勵多樣性】===
        action_counts = np.array([self.action_count[i] + 1 for i in range(4)])
        action_probs = action_counts / np.sum(action_counts)
        r_entropy = 1.0 * entropy(action_probs)  # 增加鼓勵多樣性

        # ===【總reward組成】===
        total_reward = r_combo + r_congestion + r_future + r_entropy
        return np.clip(total_reward, -5.0, 8.0)

    '''def compute_reward(self, pod, new_position, layout, action=None):
        ps_pos = (layout.picking_station_list[0].x_position, layout.picking_station_list[0].y_position)
        old_pos = (pod.storage_station.x_position, pod.storage_station.y_position)

        # 距離改善（比例越大越好）
        dist_gain = max(manhattan_distance(old_pos, ps_pos) - manhattan_distance(new_position, ps_pos), 0)
        max_dist = layout.scene_x_width + layout.scene_y_width
        r_combo = 2.0 * (dist_gain / max_dist)

        # 壅塞處罰（距離越近的 AGV 越多，懲罰越高）
        congestion = self.compute_local_density(new_position, layout)
        r_congestion = -1.5 * min(congestion, 1.0)

        # 未來重疊程度（需標準化為 [0,1] 範圍）
        future_overlap = self.compute_future_overlap(pod, layout)
        r_future = 5.0 * min(future_overlap, 1.0)

        # 探索獎勵（行動分布的 entropy）
        action_counts = np.array([self.action_count[i] + 1 for i in range(4)])  # 避免除以0
        action_probs = action_counts / np.sum(action_counts)
        r_entropy = 0.5 * entropy(action_probs)  # 稍微提高探索激勵

        #  限制 reward 範圍，避免爆炸梯度
        total_reward = r_combo + r_congestion + r_future + r_entropy
        return np.clip(total_reward, -5.0, 8.0)'''

    def compute_local_density(self, pos, layout, radius=2):
        return sum(1 for e in layout.explorer_group if manhattan_distance(e.current_place, pos) <= radius) / max(len(layout.explorer_group), 1)

    def min_agv_distance(self, pod, layout):
        pod_pos = (pod.storage_station.x_position, pod.storage_station.y_position)
        dists = [manhattan_distance(pod_pos, tuple(ex.current_place)) for ex in layout.explorer_group]
        return min(dists) if dists else layout.scene_x_width + layout.scene_y_width

    def compute_future_overlap(self, pod, layout):
        future_tasks = layout.task_list[:5]
        pod_items = set(pod.content.keys()) if pod.content else set()
        overlap = 0
        for task in future_tasks:
            task_pod = next((p for p in layout.pod_list if p.pod_id == task.pod_id), None)
            if task_pod and task_pod.content:
                needed = set(task_pod.content.keys())
                overlap += len(pod_items.intersection(needed))
        return overlap / 10.0

    def store_transition(self, state, action, reward, next_state, done):
        try:
            state_tensor = torch.tensor(state, dtype=torch.float).unsqueeze(0)
            next_state_tensor = torch.tensor(next_state, dtype=torch.float).unsqueeze(0)
            with torch.no_grad():
                max_next_q = self.target_network(next_state_tensor).max(1)[0].item()
            current_q = self.policy_network(state_tensor)[0, action].item()
            td_error = abs(reward + self.GAMMA * max_next_q - current_q)
            self.memory.add(td_error, (state, action, reward, next_state, done))
        except Exception as e:
            print(f"❌ store_transition error: {e}")

    def update_network(self):
        if self.memory.tree.n_entries < self.batch_size:
            return

        batch, idxs, is_weights = self.memory.sample(self.batch_size)
        batch = list(zip(*batch))

        states = torch.tensor(np.vstack(batch[0]), dtype=torch.float32).to(self.device)
        actions = torch.tensor(batch[1], dtype=torch.long).unsqueeze(1).to(self.device)
        rewards = torch.tensor(batch[2], dtype=torch.float32).unsqueeze(1).to(self.device)
        next_states = torch.tensor(np.vstack(batch[3]), dtype=torch.float32).to(self.device)
        dones = torch.tensor(batch[4], dtype=torch.float32).unsqueeze(1).to(self.device)
        is_weights = torch.tensor(is_weights, dtype=torch.float32).unsqueeze(1).to(self.device)

        # === Double DQN 核心邏輯 ===
        # 1️⃣ 使用 policy network 選擇 next_action
        next_actions = self.policy_network(next_states).argmax(dim=1, keepdim=True)

        # 2️⃣ 使用 target network 評估 Q 值
        next_q_values = self.target_network(next_states).gather(1, next_actions)

        # 3️⃣ 計算 TD Target
        td_target = rewards + self.GAMMA * next_q_values * (1 - dones)

        # === 取得目前 Q(s,a) ===
        current_q = self.policy_network(states).gather(1, actions)

        # === Loss 計算與更新 ===
        td_error = td_target.detach() - current_q
        loss = (is_weights * td_error.pow(2)).mean()

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # === 更新優先權（TD error 作為 priority）===
        abs_errors = td_error.abs().detach().cpu().numpy().flatten()
        for i in range(self.batch_size):
            self.memory.update(idxs[i], abs_errors[i])

        # === 記錄 Loss 趨勢 ===
        self.loss_value.append(loss.item())
        if len(self.loss_value) % 500 == 0:
            self.update_target()
            print(f" [Step {len(self.loss_value)}] Loss: {loss.item():.4f}")

    def change_learning_rate(self, times):
        if self.lr_count >= times:
            return
        decay = (self.lr_start - self.lr_end) / times
        self.lr = max(self.lr_end, self.lr - decay)
        for param_group in self.optim.param_groups:
            param_group['lr'] = self.lr
        self.lr_count += 1

    def change_explore_rate(self, times):
        if self.epsilon_count >= times:
            self.epsilon = self.epsilon_end
        else:
            decay = (self.epsilon_start - self.epsilon_end) / times
            self.epsilon = max(self.epsilon_end, self.epsilon - decay)
        self.epsilon_count += 1
    
    @staticmethod
    def smooth_curve(points, factor=0.9):
        smoothed = []
        last = points[0]
        for point in points:
            smoothed_val = last * factor + (1 - factor) * point
            smoothed.append(smoothed_val)
            last = smoothed_val
        return smoothed
