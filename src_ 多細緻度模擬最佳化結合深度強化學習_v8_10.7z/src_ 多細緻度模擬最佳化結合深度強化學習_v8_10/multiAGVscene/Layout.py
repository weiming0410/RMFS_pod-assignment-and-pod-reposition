import copy
import random
import sys
from collections import namedtuple
import os

sys.path.append(os.path.dirname(__file__))

class StorageStation:
    def __init__(self, x_position, y_position):
        self.x_position = x_position
        self.y_position = y_position

    def __repr__(self):
        return f"StorageStation({self.x_position}, {self.y_position})"

class Pod:
    def __init__(self, pod_id, storage_station, content=None):
        self.pod_id = pod_id
        self.storage_station = storage_station
        self.content = content or {}  # 對應 Excel 中每個 Pod 的 item dict
        self.picked = False

    def __repr__(self):
        return f"Pod(id={self.pod_id}, pos=({self.storage_station.x_position},{self.storage_station.y_position}))"

class Task:
    def __init__(self, pod_id, picking_id, storage_station=None, picking_position=None):
        self.pod_id = pod_id
        self.picking_id = picking_id
        self.storage_station = storage_station
        self.picking_position = picking_position

class Layout:
    def __init__(self, pod_count,
                 storage_station_x_width=3,
                 storage_station_y_width=2,
                 storage_station_x_num=2,
                 storage_station_y_num=2,
                 picking_station_number=2,
                 layout_list=None,
                 task_list=None):
        self.pod_count = pod_count
        self.storage_station_x_width = storage_station_x_width
        self.storage_station_y_width = storage_station_y_width
        self.storage_station_x_num = storage_station_x_num
        self.storage_station_y_num = storage_station_y_num
        self.storage_station_interval = 1
        self.storage_station_bottom = 3
        self.picking_station_number = picking_station_number

        if layout_list is None:
            self.storage_station_list = self.__create_storage_station()
            self.scene_x_width = self.storage_station_x_num * (self.storage_station_x_width + self.storage_station_interval) + self.storage_station_interval
            self.scene_y_width = self.storage_station_y_num * (self.storage_station_y_width + self.storage_station_interval) + self.storage_station_interval + self.storage_station_bottom
            self.picking_station_list = self.__create_picking_station()
            sorted_stations = sorted(self.storage_station_list, key=lambda st: (st.x_position, st.y_position))
            self.pod_list = [Pod(pod_id=i, storage_station=sorted_stations[i % len(sorted_stations)])
                             for i in range(min(self.pod_count, len(sorted_stations)))]
        else:
            self.storage_station_list, self.picking_station_list = self.__create_ss_ps_by_list(layout_list)
            self.scene_x_width = len(layout_list[0])
            self.scene_y_width = len(layout_list)
            self.pod_list = []

        self.task_list = []
        self.assigned_tasks = []
        self.task_finished = False

        self.layout = self.__create_layout()

        # === Reinforcement Learning 統計資料 ===
        self.simulation_stats = {
            'reposition_useful': 0,
            'reposition_total': 0,
            'fallback_count': 0,
            'deadlock_count': 0,
        }
        self.zone_usage = {}
        self.pod_usage_counter = {}
        self.pod_move_history = {}
        self.agent_training_data = []
        self.explorer_group = []

        self.storage_contents = {}  # 傳入時可用
        self.order_data = None

    def __create_storage_station(self):
        s_list = []
        for y_num in range(self.storage_station_y_num):
            for y_width in range(self.storage_station_y_width):
                y_pos = y_num * (self.storage_station_y_width + self.storage_station_interval) + y_width + 2
                for x_num in range(self.storage_station_x_num):
                    for x_width in range(self.storage_station_x_width):
                        x_pos = x_num * (self.storage_station_x_width + self.storage_station_interval) + x_width + 2
                        s_list.append(StorageStation(x_pos, y_pos))
        return s_list

    def __create_picking_station(self):
        ps_class = namedtuple('ps', 'x_position y_position')
        p_list = []
        for i in range(self.picking_station_number):
            px = int(self.scene_x_width * (i + 1) / (self.picking_station_number + 1) + 1)
            py = self.scene_y_width - 1
            p_list.append(ps_class(px, py))
        return p_list

    def __create_layout(self):
        layout = [[0] * self.scene_x_width for _ in range(self.scene_y_width)]
        for st in self.storage_station_list:
            occupied = any(pod.storage_station.x_position == st.x_position and pod.storage_station.y_position == st.y_position
                           for pod in self.pod_list)
            layout[st.y_position - 1][st.x_position - 1] = 1.8 if occupied else 1
        for p in self.picking_station_list:
            layout[p.y_position - 1][p.x_position - 1] = 2
        return layout

    def __create_ss_ps_by_list(self, layout_list):
        ps_class = namedtuple('ps', 'x_position y_position')
        ss_class = namedtuple('ss', 'x_position y_position')
        storage_list = []
        picking_list = []
        for y in range(len(layout_list)):
            for x in range(len(layout_list[0])):
                if layout_list[y][x] == 1:
                    storage_list.append(ss_class(x + 1, y + 1))
                elif layout_list[y][x] == 2:
                    picking_list.append(ps_class(x + 1, y + 1))
        return storage_list, picking_list

    def convert_solution_to_tasks(self, chromosome):
        tasks = []
        last_tail_pod_id = None

        for picking_id, batch in enumerate(chromosome):
            for idx, pid in enumerate(batch):
                if picking_id > 0 and idx == 0 and pid == last_tail_pod_id:
                    continue
                pod = next((p for p in self.pod_list if p.pod_id == pid), None)
                if pod is None or not self.picking_station_list:
                    continue
                ps = random.choice(self.picking_station_list)
                task = Task(
                    pod_id=pid,
                    picking_id=picking_id,
                    storage_station=pod.storage_station,
                    picking_position=(ps.x_position, ps.y_position)
                )
                tasks.append(task)
            if batch:
                last_tail_pod_id = batch[-1]

        self.task_list = tasks
        self.assigned_tasks = [False] * len(tasks)
        return tasks

    def update_layout(self):
        self.layout = self.__create_layout()

    def change_layout(self, x_dim, y_dim, value):
        self.layout[y_dim][x_dim] = value
