import sys
import pygame
import time
import os
import tkinter as tk
from tkinter import messagebox

from utils.utils import Direction as Dir
from utils.utils import Working as Wokring
from utils.utils import ColorBox as ColorBox
from utils.settings import SuperParas as SuperPara
#from multiAGVscene.Explorer import Explorer
import utils.astar as astar

sys.path.append(os.path.dirname(__file__))

class Scene:
    def __init__(self, layout, explorer_group, render=True, reposition_strategy="nearest", dqn_agent=None):
        self.layout = layout
        self.explorer_group = explorer_group
        self.render = render
        self.reposition_strategy = reposition_strategy
        self.dqn_agent = dqn_agent

        self.FPS = SuperPara.FPS
        self.running_time = 0
        self.border_width = 30
        self.line_width = 2
        self.cell_width = 36
        self.color_box = ColorBox()
        self.dir = Dir()

        self.x_width = layout.scene_x_width
        self.y_width = layout.scene_y_width
        self.interface_width = self.x_width * self.cell_width - (self.x_width - 1) * self.line_width
        self.interface_height = self.y_width * self.cell_width - (self.y_width - 1) * self.line_width
        self.interface_start_x = self.border_width
        self.interface_start_y = self.border_width

        self.sidebar_width = 200
        self.sidebar_height = self.interface_height + 2 * self.border_width
        self.sidebar_start_x = self.interface_width + 2 * self.border_width
        self.sidebar_start_y = 0

        self.screen_width = self.interface_width + 2 * self.border_width + self.sidebar_width
        self.screen_height = self.interface_height + 2 * self.border_width

        self.AGV_icon_scale = 0.8
        self.selected_storage_station = None
        self.eval_mode = False
        self.max_steps = 1000
        self.current_step = 0
        self.total_movement_distance = 0  # ⬅️ 儲存總移動距離作為 fitness


        if self.render:
            self.screen = None
            self.interface = None
            self.sidebar = None

    def init(self):
        self.layout.init()
        for explorer in self.explorer_group:
            explorer.init()
            explorer.set_reposition_strategy(self.reposition_strategy)
            if self.dqn_agent:
                explorer.dqn_agent = self.dqn_agent

    def render_init(self):
        if not self.render:
            return  # ⚡ 沒開啟 render，就直接跳過
        pygame.init()
        pygame.display.set_caption("multiAGV World")
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        self.screen.fill(self.color_box.GRAY_COLOR)
        self.refresh_screen()
        self.clock = pygame.time.Clock()

    def run_game(self, control_pattern="manual", render=True):
        self.render = render
        self.control_pattern = control_pattern

        self.explorer_group[0].create_explorer()

        if self.render:
            self.render_init()

        return self.run_mode()

    def run_mode(self):
        self.running_time = 0
        start_time = time.time()
        agv_moves = {explorer.explorer_name: 0 for explorer in self.explorer_group}

        while True:
            self.running_time += 1
            if self.render:
                self.create_interface()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.end_simulation(start_time, agv_moves)
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self._handle_mouse_click(pygame.mouse.get_pos())

            all_done = True
            for explorer in self.explorer_group:
                if not explorer.has_created:
                    explorer.create_explorer()
                    all_done = False
                    continue
                if self.layout.task_finished or explorer.all_assigned:
                    continue

                act = explorer.find_path_astar(self.explorer_group)
                reward, done = explorer.execute_action(act)
                if not done:
                    agv_moves[explorer.explorer_name] += 1
                    all_done = False

            self.refresh_screen()

            if all_done:
                self.end_simulation(start_time, agv_moves)
                return

    def _handle_mouse_click(self, pos):
        if not self.render:
            return  # ⚡ 沒開啟 render，就直接跳過
        if (self.interface_start_x <= pos[0] < self.interface_start_x + self.interface_width and
                self.interface_start_y <= pos[1] < self.interface_start_y + self.interface_height):
            gx = (pos[0] - self.interface_start_x) // self.cell_width + 1
            gy = (pos[1] - self.interface_start_y) // self.cell_width + 1
            if any((st.x_position, st.y_position) == (gx, gy) for st in self.layout.storage_station_list):
                self.selected_storage_station = (gx, gy)
            else:
                self.selected_storage_station = None

    def end_simulation(self, start_time, moves_dict):
        if not self.render:
            return  # ⚡ 沒開啟 render，就直接跳過
        total_time = round(time.time() - start_time, 2)
        print(f"\n⏳ 總執行時間: {total_time} 秒")
        dist_sum = sum(moves_dict.values())
        for agv, dist in moves_dict.items():
            print(f"🚗 {agv} 總移動距離: {dist} 步")
        print(f"🚀 總移動距離 (所有 AGV 合計): {dist_sum} 步")

        if self.eval_mode:
            return
        else:
            root = tk.Tk()
            root.withdraw()
            ans = messagebox.askyesno("結束模擬", "是否要結束模擬？")
            root.destroy()
            if ans:
                pygame.quit()
                sys.exit()
            else:
                #print("使用者選擇不結束模擬。")
                self.paused_loop()

    def refresh_screen(self):
        if not self.render:
            return  # ⚡ 沒開啟 render，就直接跳過
        self.create_interface()
        for explorer in self.explorer_group:
            self.patch_agv_icon(explorer)
        self.create_sidebar()
        self.screen.blit(self.interface, (self.interface_start_x, self.interface_start_y))
        self.screen.blit(self.sidebar, (self.sidebar_start_x, self.sidebar_start_y))
        pygame.display.flip()

    def create_interface(self):
        if not self.render:
            return  # ⚡ 沒開啟 render，就直接跳過
        
        self.interface = pygame.Surface((self.interface_width, self.interface_height), flags=pygame.HWSURFACE)
        self.interface.fill(self.color_box.WHITE_COLOR)
        for yy in range(self.y_width):
            for xx in range(self.x_width):
                rect = pygame.Rect(xx * (self.cell_width - self.line_width),
                                   yy * (self.cell_width - self.line_width),
                                   self.cell_width, self.cell_width)
                pygame.draw.rect(self.interface, self.color_box.BLACK_COLOR, rect, self.line_width)
                pos = (xx + 1, yy + 1)
                if any((ps.x_position, ps.y_position) == pos for ps in self.layout.picking_station_list):
                    self.draw_block(self.interface, self.color_box.GRAY_COLOR, xx, yy)
                else:
                    is_storage = False
                    for st in self.layout.storage_station_list:
                        if (st.x_position, st.y_position) == pos:
                            is_storage = True
                            occupied = any((pod.storage_station.x_position, pod.storage_station.y_position) == (st.x_position, st.y_position)
                                           for pod in self.layout.pod_list)
                            if occupied:
                                self.draw_block(self.interface, self.color_box.RED_COLOR, xx, yy)
                            else:
                                self.draw_block(self.interface, self.color_box.PINK_COLOR, xx, yy)
                            break
                    if not is_storage:
                        self.draw_block(self.interface, self.color_box.WHITE_COLOR, xx, yy)

    def patch_agv_icon(self, explorer):
        if not self.render:
            return  # ⚡ 沒開啟 render，就直接跳過
        try:
            agv_img = pygame.image.load(explorer.icon_path)
            agv_img = pygame.transform.scale(agv_img, (int(self.cell_width * self.AGV_icon_scale),
                                                       int(self.cell_width * self.AGV_icon_scale)))
            angle = self.image_rotate_angle(explorer.action_str)
            agv_img = pygame.transform.rotate(agv_img, angle)
        except pygame.error:
            agv_img = pygame.Surface((self.cell_width, self.cell_width))
            agv_img.fill(self.color_box.RED_COLOR)
        px, py = self.position_rectify(explorer.current_place[0], explorer.current_place[1])
        self.interface.blit(agv_img, (px, py))

    def image_rotate_angle(self, action):
        mapping = {0: 90, 1: 0, 2: -90, 3: 180}
        return mapping.get(self.dir.action_str_value(action), 0)

    def position_rectify(self, x_dim, y_dim):
        xx = (x_dim - 1) * (self.cell_width - self.line_width) + self.line_width
        yy = (y_dim - 1) * (self.cell_width - self.line_width) + self.line_width
        return xx, yy

    def draw_block(self, surf, color, xx, yy):
        rect = (xx * (self.cell_width - self.line_width) + self.line_width,
                yy * (self.cell_width - self.line_width) + self.line_width,
                self.cell_width - self.line_width,
                self.cell_width - self.line_width)
        pygame.draw.rect(surf, color, rect)

    def create_sidebar(self):
        if not self.render:
            return  # ⚡ 沒開啟 render，就直接跳過
        self.sidebar = pygame.Surface((self.sidebar_width, self.sidebar_height), flags=pygame.HWSURFACE)
        self.sidebar.fill(self.color_box.GRAY_COLOR)
        fnt = pygame.font.SysFont("Times New Roman", 30)
        title = fnt.render("RMFS Simulation", True, self.color_box.BLACK_COLOR)
        time_txt = fnt.render("Time:" + str(self.running_time), True, self.color_box.BLACK_COLOR)
        rect_t = title.get_rect()
        self.sidebar.blit(title, (self.sidebar_width // 2 - rect_t.width // 2, self.sidebar_height // 15))
        self.sidebar.blit(time_txt, (self.sidebar_width // 2 - rect_t.width // 2, self.sidebar_height // 15 + 40))
        if self.selected_storage_station:
            fnt2 = pygame.font.SysFont("Times New Roman", 16)
            info_title = fnt2.render("Storage_station " + str(self.selected_storage_station) + ":", True, self.color_box.BLACK_COLOR)
            self.sidebar.blit(info_title, (10, self.sidebar_height // 2))

    def paused_loop(self):
        fnt = pygame.font.SysFont("Times New Roman", 24)
        msg = fnt.render("模擬已完成。按關閉視窗退出。", True, self.color_box.RED_COLOR)
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            self.refresh_screen()
            self.screen.blit(msg, (self.screen_width // 2 - msg.get_width() // 2,
                                   self.screen_height // 2 - msg.get_height() // 2))
            pygame.display.flip()
            self.clock.tick(self.FPS)
    
    '''def simulate_full(self):
        start_time = time.time()
        agv_movements = {explorer.explorer_name: 0 for explorer in self.explorer_group}

        if self.render and self.screen is None:
            self.render_init()

        self.running_time = 0
        self.layout.task_finished = False
        step_limit = 1000

        transitions = []  # 專用於 DQN 訓練

        while not self.layout.task_finished and self.running_time < step_limit:
            self.running_time += 1
            if self.render:
                self.create_interface()

            for event in pygame.event.get():
                if event.type == pygame.QUIT and not self.eval_mode:
                    pygame.quit()
                    sys.exit()

            for explorer in self.explorer_group:
                if not explorer.has_created:
                    explorer.create_explorer()
                    continue

                if self.layout.task_finished or explorer.all_assigned:
                    continue

                action = explorer.find_path_astar(self.explorer_group)
                reward, is_end = explorer.execute_action(action)

                if not is_end:
                    agv_movements[explorer.explorer_name] += 1

                # ✅ 僅當策略為 dqn 時，才收集 transition
                if self.reposition_strategy == "dqn" and hasattr(explorer, 'last_transition') and explorer.last_transition:
                    transitions.append(explorer.last_transition)
                    explorer.last_transition = None

            if self.render:
                self.refresh_screen()

        if self.running_time >= step_limit:
            print("⚠️ 模擬超過步數上限，強制結束")
            for explorer in self.explorer_group:
                print(f"🚧 {explorer.explorer_name} | 位置: {explorer.current_place} | 目標: {explorer.target_position} | 任務階段: {explorer.task_stage}")

        total_distance = sum(explorer.total_movement_distance for explorer in self.explorer_group)
        print(f"📊 模擬總步數: {total_distance}")

        # ✅ 僅當策略為 dqn 且有收集到 transition 時，才進行 DQN 訓練
        if self.reposition_strategy == "dqn" and self.dqn_agent and transitions:
            for state, action, reward, next_state, done in transitions:
                self.dqn_agent.store_transition(state, action, reward, next_state, done)
            self.dqn_agent.update_network()

        return total_distance'''
    
    def simulate_full(self):
        #start_time = time.time()
        agv_movements = {explorer.explorer_name: 0 for explorer in self.explorer_group}

        if self.render and (self.screen is None):
            self.render_init()

        self.running_time = 0
        self.layout.task_finished = False
        step_limit = 10000
        transitions = []
        self.total_movement_distance = 0

        while not self.layout.task_finished and self.running_time < step_limit:
            self.running_time += 1

            if self.render:
                self.create_interface()
                for event in pygame.event.get():
                    if event.type == pygame.QUIT and not self.eval_mode:
                        pygame.quit()
                        sys.exit()

            for explorer in self.explorer_group:
                if not explorer.has_created:
                    explorer.create_explorer()
                    continue
                if self.layout.task_finished or explorer.all_assigned:
                    continue

                action = explorer.find_path_astar(self.explorer_group)
                reward, is_end = explorer.execute_action(action)

                if not is_end:
                    agv_movements[explorer.explorer_name] += 1

                if self.reposition_strategy == "dqn" and hasattr(explorer, 'last_transition') and explorer.last_transition:
                    transitions.append(explorer.last_transition)
                    explorer.last_transition = None

            if self.render:
                self.refresh_screen()

        if self.running_time >= step_limit:
            self.layout.simulation_stats['deadlock_count'] += 1
            print("⚠️ 模擬超過步數上限，強制結束")

        total_distance = sum(explorer.total_movement_distance for explorer in self.explorer_group)
        print(f"📊 模擬總步數: {total_distance}")

        if self.reposition_strategy == "dqn" and self.dqn_agent and transitions:
            for state, action, reward, next_state, done in transitions:
                self.dqn_agent.store_transition(state, action, reward, next_state, done)
            self.dqn_agent.update_network()

        return total_distance, self.running_time