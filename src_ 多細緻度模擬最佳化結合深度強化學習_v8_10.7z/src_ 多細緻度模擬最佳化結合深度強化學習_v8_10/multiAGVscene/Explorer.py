import copy
import sys
import random
import utils.astar as astar
from utils.utils import Direction as Dir
from utils.utils import Working as Wokring
from utils.settings import SuperParas as SuperPara
import os
import time

sys.path.append(os.path.dirname(__file__))

class Explorer:
    def __init__(self, layout, veh_name="veh1", icon_name="veh1", reposition_strategy="nearest", dqn_agent=None):
        self.layout = layout
        self.reposition_strategy = reposition_strategy
        self.dqn_agent = dqn_agent

        self.dir = Dir()
        self.working_manager = Wokring()

        self.explorer_name = veh_name
        self.icon_path = self.get_icon()
        self.has_created = False

        self.action_str = self.dir.value_str[1]
        self.action_list = []
        self.current_place = [1, 1]
        self.last_place = [1, 1]
        self.target_position = [1, 1]
        self.task_order = 0
        self.task_stage = 0
        self.running_state = "Start"
        self.loaded = False
        self.all_assigned = False
        self.time_counting = 0  # ✅ 初始化計時器屬性

        self.always_loaded = SuperPara.Explorer_Always_Loaded
        self.always_empty = SuperPara.Explorer_Always_Empty

        self.action_distribution = [0, 0, 0, 0, 0]
        self.total_movement_distance = 0

        # 壅塞偵測次數
        self.congestion_count = 0

        self.init()

    def init(self):
        self.current_place = [1, 1]
        self.last_place = [1, 1]
        self.task_order = 0
        self.task_stage = 0
        self.running_state = "Start"
        self.loaded = False
        self.has_created = False
        self.all_assigned = False
        self.action_list = []
        self.total_movement_distance = 0
        self.congestion_count = 0
        self.time_counting = 0  # ✅ 重設時間

    def get_icon(self):
        return "multiAGVscene/icons/" + str(self.explorer_name) + "_1.png"

    def create_explorer(self):
        self.has_created = True
        self.get_task()

    def get_task(self):
        if not self.has_created:
            return

        if all(self.layout.assigned_tasks):
            self.all_assigned = True
            self.layout.task_finished = True
            self.running_state = "AllTaskFinished"
            return

        if self.task_stage == 0:
            min_dist = float('inf')
            chosen_index = None
            for i, task in enumerate(self.layout.task_list):
                if not self.layout.assigned_tasks[i]:
                    d = abs(task.storage_station.x_position - self.current_place[0]) + abs(task.storage_station.y_position - self.current_place[1])
                    if d < min_dist:
                        min_dist = d
                        chosen_index = i
            if chosen_index is not None:
                task = self.layout.task_list[chosen_index]
                self.target_position = [task.storage_station.x_position, task.storage_station.y_position]
                self.layout.assigned_tasks[chosen_index] = True
                self.task_index = chosen_index
                self.associated_pod_id = task.pod_id
            else:
                self.all_assigned = True
                self.layout.task_finished = True
                return

        elif self.task_stage == 1:
            if self.layout.picking_station_list:
                ps = self.layout.picking_station_list[0]
                self.target_position = [ps.x_position, ps.y_position]

        elif self.task_stage == 2:
            if hasattr(self, "associated_pod_id"):
                pid = self.associated_pod_id
                pod = next((p for p in self.layout.pod_list if p.pod_id == pid), None)
                if pod is not None:
                    self.target_position = [pod.storage_station.x_position, pod.storage_station.y_position]
                else:
                    task = self.layout.task_list[self.task_index]
                    self.target_position = [task.storage_station.x_position, task.storage_station.y_position]
            else:
                if self.layout.task_list:
                    task = self.layout.task_list[0]
                    self.target_position = [task.storage_station.x_position, task.storage_station.y_position]

        self.load_condition(self.task_stage)


    def execute_action(self, input_action, all_info=[], explorer_group=None):
        self.action_distribution = [0, 0, 0, 0, 0]
        action_val, action_str = self.action_format(input_action)
        self.action_distribution[action_val] = 1
        self.action_str = action_str

        move = self.action_logical(action_val)
        new_place = [self.current_place[0] + move[0], self.current_place[1] + move[1]]

        reward, is_end = self.check_action(all_info, new_place, explorer_group)

        if not is_end:
            self.current_place = new_place
            self.total_movement_distance += 1

        return reward, is_end

    def action_format(self, input_action):
        if isinstance(input_action, str):
            val = self.dir.action_str_value(input_action)
        else:
            val = input_action
        return val, self.dir.action_value_str(val)

    def action_logical(self, action_value):
        mapping = {0: (0, -1), 1: (1, 0), 2: (0, 1), 3: (-1, 0), 4: (0, 0)}
        return mapping.get(action_value, (0, 0))

    def check_action(self, all_info, new_place, explorer_group):
        reward, is_end = 0, False
        self.running_state = "Normal"

        # 越界、撞牆
        if new_place[0] < 1 or new_place[1] < 1 or \
           new_place[0] > self.layout.scene_x_width or new_place[1] > self.layout.scene_y_width:
            return -1, True

        if any((st.x_position, st.y_position) == tuple(new_place) for st in self.layout.storage_station_list) and \
           self.loaded and new_place != self.target_position:
            return -1, True

        if any((ps.x_position, ps.y_position) == tuple(new_place) for ps in self.layout.picking_station_list) and \
           new_place != self.target_position:
            return -1, True

        # 壅塞處理
        if explorer_group:
            for other in explorer_group:
                if other.explorer_name != self.explorer_name and other.current_place == new_place:
                    if other.get_priority() >= self.get_priority():
                        self.running_state = "avoidance: yield to higher priority"
                        self.congestion_count += 1
                        self.layout.simulation_stats['fallback_count'] += 1

                        from strategies import reposition_rules
                        if hasattr(self, "associated_pod_id"):
                            pid = self.associated_pod_id
                            pod = next((p for p in self.layout.pod_list if p.pod_id == pid), None)
                            if pod:
                                new_coords = reposition_rules.safe_reposition_pod(pod, self.layout, strategy=self.reposition_strategy)
                                if new_coords:
                                    pod.storage_station = type(pod.storage_station)(*new_coords)
                                    self.target_position = list(new_coords)
                                    #print(f"⚠️ {self.explorer_name} 壅塞觸發 fallback ➜ Pod {pid} 新儲位: {new_coords}")
                        return 4, True

        if new_place == self.target_position:
            self.continue_working()
            return 1, False

        return reward, is_end

    def continue_working(self):
        if self.task_stage == 2:
            from strategies import reposition_rules

            if hasattr(self, "associated_pod_id"):
                pid = self.associated_pod_id
                current_pod = next((p for p in self.layout.pod_list if p.pod_id == pid), None)
                if current_pod is not None:
                    original_pos = (current_pod.storage_station.x_position, current_pod.storage_station.y_position)

                    if self.reposition_strategy == "dqn" and self.dqn_agent is not None:
                        state = self.dqn_agent.get_state(current_pod, self.layout)
                        action = self.dqn_agent.choose_action(state)
                        new_coords = self.dqn_agent.apply_action(current_pod, action, self.layout)
                        next_state = self.dqn_agent.get_state(current_pod, self.layout)
                        reward = self.dqn_agent.compute_reward(current_pod, new_coords, self.layout)
                        done = False
                        transition = (state, action, reward, next_state, done)
                        self.layout.agent_training_data.append(transition)
                        self.dqn_agent.log_episode_reward(reward)
                    elif self.reposition_strategy == "none":
                        new_coords = original_pos  # ✅ 不重新定位
                    else:
                        new_coords = reposition_rules.safe_reposition_pod(current_pod, self.layout, strategy=self.reposition_strategy)

                    if original_pos != new_coords:
                        #print(f"📦 Pod {pid} 原始位置 {original_pos} → ➡️ 新位置 {new_coords}")
                        new_storage = type(current_pod.storage_station)(*new_coords)
                        new_pod = type(current_pod)(current_pod.pod_id, new_storage, current_pod.content)
                        for i, p in enumerate(self.layout.pod_list):
                            if p.pod_id == pid:
                                self.layout.pod_list[i] = new_pod
                                break
                        for i, task in enumerate(self.layout.task_list):
                            if task.pod_id == pid:
                                self.layout.task_list[i].storage_station = new_storage
                                break

        self.task_stage = (self.task_stage + 1) % 3
        if self.task_stage == 0:
            self.task_order += 1
        self.get_task()

    
    def find_path_astar(self, explorer_group=None):
        matrix = self.create_valid_matrix(explorer_group, use_soft_block=True)
        start = (self.current_place[0] - 1, self.current_place[1] - 1)
        goal = (self.target_position[0] - 1, self.target_position[1] - 1)

        for attempt in range(3):
            finder = astar.FindPathAstar(matrix, start, goal)
            found, path_list, path_map, action_list = finder.run_astar_method()
            if found and action_list:
                return action_list[0]

            # 若失敗，嘗試移除周邊障礙以避免死鎖
            x, y = self.current_place
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    nx, ny = x + dx - 1, y + dy - 1
                    if 0 <= nx < self.layout.scene_x_width and 0 <= ny < self.layout.scene_y_width:
                        matrix[ny][nx] = 1

        # 記錄壅塞與 fallback 次數
        self.congestion_count += 1
        self.layout.simulation_stats['fallback_count'] += 1
        #print(f"⚠️ {self.explorer_name} 無法找到通往 {self.target_position} 的路徑，執行 fallback")
        return "STOP"

    def create_valid_matrix(self, explorer_group, use_soft_block=False):
        w, h = self.layout.scene_x_width, self.layout.scene_y_width
        matrix = [[1] * w for _ in range(h)]

        for st in self.layout.storage_station_list:
            matrix[st.y_position - 1][st.x_position - 1] = 0 if self.loaded else 1

        for ps in self.layout.picking_station_list:
            matrix[ps.y_position - 1][ps.x_position - 1] = 0

        if use_soft_block and explorer_group:
            for e in explorer_group:
                if e.explorer_name != self.explorer_name and e.get_priority() >= self.get_priority():
                    x, y = e.current_place
                    matrix[y - 1][x - 1] = 0

        # 確保起點與終點可通行
        tx, ty = self.target_position[0] - 1, self.target_position[1] - 1
        matrix[ty][tx] = 1
        cx, cy = self.current_place[0] - 1, self.current_place[1] - 1
        matrix[cy][cx] = 1

        return matrix

    def get_priority(self):
        """
        任務優先權判定：
        - 任務執行階段為搬運中（非取貨階段）則優先。
        - 等待時間越久，優先級越高。
        """
        base_priority = 1 if self.task_stage != 0 else 0
        wait_bonus = 0.1 * self.time_counting
        return base_priority + wait_bonus

    def choose_alternative_target(self, explorer_group):
        """
        當無法找到路徑時，選擇角落作為暫時避難點，避免阻礙其他 AGV。
        """
        safe_candidates = [
            (1, 1),
            (self.layout.scene_x_width, 1),
            (1, self.layout.scene_y_width),
            (self.layout.scene_x_width, self.layout.scene_y_width)
        ]
        for cand in safe_candidates:
            if not any(e.current_place == list(cand) for e in explorer_group if e.explorer_name != self.explorer_name):
                return list(cand)
        return self.current_place  # 若無安全區域，原地等待

    def avoid_collision(self, explorer_group):
        """
        額外避障策略：嘗試重新規劃路徑，若多次失敗則改變目標點。
        """
        max_attempts = 3
        for attempt in range(max_attempts):
            valid_matrix = self.create_valid_matrix(explorer_group)
            for e in explorer_group:
                if e.explorer_name != self.explorer_name and e.get_priority() >= self.get_priority():
                    x, y = e.current_place
                    valid_matrix[y - 1][x - 1] = 0
            start_coord = (self.current_place[0] - 1, self.current_place[1] - 1)
            goal_coord = (self.target_position[0] - 1, self.target_position[1] - 1)
            finder = astar.FindPathAstar(valid_matrix, start_coord, goal_coord)
            found, path_list, path_map, action_list = finder.run_astar_method()
            if found and action_list:
                return action_list[0]
            else:
                time.sleep(0.1)  # 短暫等待再嘗試

        alt_target = self.choose_alternative_target(explorer_group)
        self.target_position = alt_target
        return 4  # 停止等待

    def load_condition(self, task_stage):
        if self.always_loaded:
            self.loaded = True
        elif self.always_empty:
            self.loaded = False
        else:
            self.loaded = task_stage in [1, 2]