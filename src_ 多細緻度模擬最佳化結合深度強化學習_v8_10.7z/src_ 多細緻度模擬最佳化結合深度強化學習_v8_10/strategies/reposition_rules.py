import math
import random

def manhattan_distance(pos1, pos2):
    return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

def get_available_storage_stations(layout):
    """
    取得所有未被佔用的儲存站座標。
    """
    occupied = {(p.storage_station.x_position, p.storage_station.y_position) for p in layout.pod_list}
    return [st for st in layout.storage_station_list if (st.x_position, st.y_position) not in occupied]

def get_top_k_storage(layout, percent=0.25):
    """
    取得距離工作站最近的前 k% 儲存位址，用於 Cache 策略與獎勵計算。
    """
    if not layout.storage_station_list or not layout.picking_station_list:
        return []

    ps = layout.picking_station_list[0]
    ps_pos = (ps.x_position, ps.y_position)

    storage_distances = []
    for st in layout.storage_station_list:
        st_pos = (st.x_position, st.y_position)
        dist = manhattan_distance(st_pos, ps_pos)
        storage_distances.append((dist, st_pos))

    storage_distances.sort()
    top_k_count = max(1, int(len(storage_distances) * percent))
    top_k_positions = [pos for _, pos in storage_distances[:top_k_count]]
    return top_k_positions

def reposition_nearest(pod, layout):
    original_pos = (pod.storage_station.x_position, pod.storage_station.y_position)
    available_spaces = get_available_storage_stations(layout)

    if not layout.picking_station_list:
        #print(f"⚠️ Pod {pod.pod_id} | Nearest策略失敗：無可用工作站資訊 → 維持原位 {original_pos}")
        return original_pos

    ps_pos = (layout.picking_station_list[0].x_position, layout.picking_station_list[0].y_position)
    sorted_spaces = sorted(available_spaces, key=lambda s: manhattan_distance((s.x_position, s.y_position), ps_pos))

    for s in sorted_spaces:
        new_pos = (s.x_position, s.y_position)
        if new_pos != original_pos:
            #print(f"📦 Pod {pod.pod_id} | Nearest策略 → {original_pos} → ➡️ {new_pos}")
            return new_pos

    if available_spaces:
        fallback = available_spaces[0]
        #print(f"⚠️ Pod {pod.pod_id} | Nearest策略 Fallback → {fallback.x_position, fallback.y_position}")
        return (fallback.x_position, fallback.y_position)

    return original_pos

def reposition_cache(pod, layout):
    available_spaces = get_available_storage_stations(layout)
    if not available_spaces:
        #print(f"⚠️ Pod {pod.pod_id} | Cache策略失敗：無可用儲位")
        return None

    pod_pos = (pod.storage_station.x_position, pod.storage_station.y_position)
    sorted_slots = sorted(available_spaces, key=lambda s: manhattan_distance(pod_pos, (s.x_position, s.y_position)))
    top_25_percent = sorted_slots[:max(1, len(sorted_slots) // 4)]

    if top_25_percent:
        slot = random.choice(top_25_percent)
        pos = (slot.x_position, slot.y_position)
        #print(f"📦 Pod {pod.pod_id} | Cache策略 → ➡️ {pos}")
        return pos

    # Fallback
    ps_pos = (layout.picking_station_list[0].x_position, layout.picking_station_list[0].y_position)
    sorted_nearby = sorted(available_spaces, key=lambda s: manhattan_distance((s.x_position, s.y_position), ps_pos))
    fallback = random.choice(sorted_nearby[:max(1, len(sorted_nearby)//3)])
    #print(f"⚠️ Pod {pod.pod_id} | Cache策略 Fallback → {fallback.x_position, fallback.y_position}")
    return (fallback.x_position, fallback.y_position)

def reposition_utility(pod, layout):
    available_spaces = get_available_storage_stations(layout)
    if not available_spaces:
        #print(f"⚠️ Pod {pod.pod_id} | Utility策略失敗：無可用儲位")
        return None

    pod_pos = (pod.storage_station.x_position, pod.storage_station.y_position)
    if not layout.picking_station_list:
        return reposition_nearest(pod, layout)

    ps_pos = (layout.picking_station_list[0].x_position, layout.picking_station_list[0].y_position)
    original_dist = manhattan_distance(pod_pos, ps_pos)

    def utility_score(slot):
        slot_pos = (slot.x_position, slot.y_position)
        to_ps = manhattan_distance(slot_pos, ps_pos)
        move_cost = manhattan_distance(pod_pos, slot_pos)
        return (original_dist - to_ps) - move_cost + random.uniform(-0.1, 0.1)

    best_slot = max(available_spaces, key=utility_score)
    best_coords = (best_slot.x_position, best_slot.y_position)
    #print(f"📦 Pod {pod.pod_id} | Utility策略 → {pod_pos} → ➡️ {best_coords}")
    return best_coords

def reposition_pod_by_strategy(pod, layout, strategy="nearest"):
    available_slots = get_available_storage_stations(layout)
    if not available_slots:
        #print(f"❌ Pod {pod.pod_id} | 無可用儲位，無法進行 {strategy} 重新定位")
        return None

    if strategy == "nearest":
        return reposition_nearest(pod, layout)
    elif strategy == "cache":
        return reposition_cache(pod, layout)
    elif strategy == "utility":
        return reposition_utility(pod, layout)
    else:
        #print(f"⚠️ 未知策略 {strategy}，維持原位")
        return (pod.storage_station.x_position, pod.storage_station.y_position)

def safe_reposition_pod(pod, layout, strategy):
    if strategy == "dqn" and hasattr(layout, "agent"):
        state = layout.agent.get_state(pod, layout)
        action = layout.agent.choose_action(state)
        new_coords = layout.agent.apply_action(pod, action, layout)
    else:
        new_coords = reposition_pod_by_strategy(pod, layout, strategy)

    occupied_positions = {(p.storage_station.x_position, p.storage_station.y_position) for p in layout.pod_list if p.pod_id != pod.pod_id}
    
    if not new_coords or new_coords in occupied_positions:
        for ss in layout.storage_station_list:
            fallback_coords = (ss.x_position, ss.y_position)
            if fallback_coords not in occupied_positions:
                print(f"🚨 Pod {pod.pod_id} | Fallback 啟動 → 安全儲位 {fallback_coords}")
                return fallback_coords
        #print(f"❌ Pod {pod.pod_id} | 所有儲位皆被佔用，維持原位")
        return (pod.storage_station.x_position, pod.storage_station.y_position)

    return new_coords
