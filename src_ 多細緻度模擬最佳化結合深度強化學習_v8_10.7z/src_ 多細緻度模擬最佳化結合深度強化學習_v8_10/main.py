import pandas as pd
import sys
import pygame
from multiAGVscene.Layout import Layout
from multiAGVscene.Explorer import Explorer
from multiAGVscene.Scene import Scene

sys.path.append(".")

def load_pod_data(file_path):
    """
    讀取 Excel 檔案中的 Pod 工作表，返回 pod_count 與儲存站物品資訊字典
    由於目前資料集中僅提供儲存站的物品品項資訊，
    儲存站的 x, y 座標將由程式自行定義，因此此處以每一列的順序為索引
    """
    try:
        raw_pod_sheet = pd.read_excel(file_path, sheet_name='Pod')
        # 如果存在 'Unnamed: 0' 欄位，則捨棄
        if 'Unnamed: 0' in raw_pod_sheet.columns:
            raw_pod_sheet = raw_pod_sheet.drop(columns=['Unnamed: 0'])
        pod_count = len(raw_pod_sheet)
        storage_contents = {}
        # 每一列代表一個儲存站的物品資訊，使用 row index 作為 key
        for idx, row in raw_pod_sheet.iterrows():
            info = row.to_dict()
            storage_contents[idx] = info
        return pod_count, storage_contents
    except Exception as e:
        print(f"⚠️ 無法讀取 Excel 檔案中的 Pod 工作表，使用預設 pod_count: 4 ({str(e)})")
        return 4, {}

def load_order_data(file_path):
    """
    讀取 Excel 檔案中的 Order 工作表，並回傳 DataFrame
    """
    try:
        raw_order_sheet = pd.read_excel(file_path, sheet_name='Order')
        return raw_order_sheet
    except Exception as e:
        print(f"⚠️ 無法讀取 Excel 檔案中的 Order 工作表: {str(e)}")
        return None

def main(file_path=None):
    agv_count = 2
    # 讀取 Pod 工作表
    pod_count, pod_data = load_pod_data(file_path)
    # 讀取 Order 工作表
    order_data = load_order_data(file_path)
    
    print("Pod 工作表內容:")
    print(pod_data)
    print("Order 工作表內容:")
    print(order_data)
    
    # 建立 Layout，pod_count 用來決定可用貨架數量
    ss_x_width, ss_y_width, ss_x_num, ss_y_num, ps_num = 4, 2, 2, 2, 1
    layout = Layout(storage_station_x_width=ss_x_width, 
                    storage_station_y_width=ss_y_width,
                    storage_station_x_num=ss_x_num, 
                    storage_station_y_num=ss_y_num,
                    picking_station_number=ps_num, 
                    pod_count=pod_count)
    # 重新映射 Pod 工作表資料：
    # 假設 Pod 工作表的每一列依序對應 layout.pod_positions 中的儲存站
    new_storage_contents = {}
    for i, coord in enumerate(layout.pod_positions):
        if i in pod_data:
            new_storage_contents[coord] = pod_data[i]
    layout.storage_contents = new_storage_contents
    # 將 Order 資料存入 Layout 方便後續使用（如需要）
    layout.order_data = order_data

    explorer_group = [Explorer(layout, f"veh{i+1}") for i in range(agv_count)]
    multi_agv_scene = Scene(layout, explorer_group)
    
    control_mode = "A_star"
    print(f"🚀 模型控制模式：{control_mode}")
    multi_agv_scene.run_game(control_pattern=control_mode, render=False)
    print("模擬完成。")
    
if __name__ == '__main__':
    file_path = "exp1_O3K60k30_P4_r3827.xlsx"  # 請填入您的 Excel 檔案路徑
    main(file_path=file_path)



'''def load_pod_data(file_path):
    """
    讀取 Excel 檔案中的 Pod 工作表，返回所需的料架數量。
    """
    try:
        raw_pod_sheet = pd.read_excel(file_path, sheet_name='Pod', header=None).iloc[1:, 1:].reset_index(drop=True)
        pod_count = len(raw_pod_sheet)
        return pod_count
    except Exception as e:
        print(f"⚠️ 無法讀取 Excel 檔案，使用預設 pod_count: 4 ({str(e)})")
        return 4  # 如果讀取失敗，則預設為 4

def main(file_path=None):
    """
    主執行函式：執行 RMFS 模擬，不使用基因演算法。
    """
    # 設定 AGV 數量
    agv_count = 2  # 根據需求動態調整
    pod_count = load_pod_data(file_path)  # 讀取 Excel 內的 Pod 數量

    """--------------創建 multiAGV 物件--------------"""
    # 1. 創建 Layout
    ss_x_width, ss_y_width, ss_x_num, ss_y_num, ps_num = 4, 2, 2, 2, 1
    layout = Layout(storage_station_x_width=ss_x_width, 
                    storage_station_y_width=ss_y_width,
                    storage_station_x_num=ss_x_num, 
                    storage_station_y_num=ss_y_num,
                    picking_station_number=ps_num, 
                    pod_count=pod_count)  

    # 2. 創建 AGV 探索者
    explorer_group = [Explorer(layout, f"veh{i+1}") for i in range(agv_count)]

    # 3. 創建場景
    multi_agv_scene = Scene(layout, explorer_group)

    """--------------執行 RMFS 模擬--------------"""
    control_mode = "A_star"  # 預設使用 A* 演算法來運行 AGV
    print(f"🚀 模型控制模式：{control_mode}")
    multi_agv_scene.run_game(control_pattern=control_mode)
    print("模擬完成。")

if __name__ == '__main__':
    file_path = "exp1_O3K60k30_P4_r3827.xlsx"  # 這裡填入你的 Excel 檔案
    main(file_path=file_path)'''
