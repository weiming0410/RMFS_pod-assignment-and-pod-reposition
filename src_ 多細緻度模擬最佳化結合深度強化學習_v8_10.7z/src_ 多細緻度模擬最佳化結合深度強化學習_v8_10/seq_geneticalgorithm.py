import pandas as pd
import time
import copy
import random
import matplotlib.pyplot as plt
from multiAGVscene.Layout import Layout
from multiAGVscene.Explorer import Explorer
from multiAGVscene.Scene import Scene
import utils.astar as astar
from DQN import Net, Agent
import torch
import numpy as np

# === 初始化 DQN Agent ===
policy_net = Net()
target_net = Net()
agent = Agent(policy_net, target_net)

use_trained_model = True   # 切換 True 為推論模式，False 為訓練模式

if use_trained_model:
    try:
        agent.policy_network.load_state_dict(torch.load("dqn_policy_model.pth"))
        agent.policy_network.eval()
        agent.epsilon = 0.0
        print("✅ 已載入訓練完成的 DQN 模型，進入推論模式")
    except Exception as e:
        print(f"❌ 無法載入模型，將進行重新訓練: {e}")
        use_trained_model = False
else:
    print("🛈 啟動 DQN 訓練模式")

##############################
# 1) 資料載入與基礎函式
##############################

def load_data(file_path):
    """讀取訂單 (Order) 與料架 (Pod) 資料"""
    order_sheet = pd.read_excel(file_path, sheet_name='Order', header=None).iloc[1:, 1:].reset_index(drop=True)
    raw_pod_sheet = pd.read_excel(file_path, sheet_name='Pod', header=None).iloc[1:, 1:].reset_index(drop=True)
    raw_pod_sheet.columns = raw_pod_sheet.columns.astype(int)

    pod_supply = {
        pid: {itm: val for itm, val in row.to_dict().items() if val > 0}
        for pid, row in raw_pod_sheet.iterrows()
    }
    return order_sheet, pod_supply


def get_pod_coverage_fast(needed_items, pod_data):
    """計算單一 Pod 對需求項目的覆蓋率"""
    return sum(min(needed_items.get(item, 0), qty) for item, qty in pod_data.items())


def update_items_and_pod_fast(needed_items, pod_data):
    """更新需求與 Pod 庫存數量，消耗對應物料"""
    for item in list(needed_items.keys()):
        if item in pod_data:
            used = min(needed_items[item], pod_data[item])
            needed_items[item] -= used
            pod_data[item] -= used

            if pod_data[item] <= 0:
                del pod_data[item]
            if needed_items[item] <= 0:
                del needed_items[item]

'''def load_data(file_path):
    """
    讀取 Order 與 Pod 數據，不包含 Storage，因為儲存站由 Layout 生成。
    這裡直接讀取原始數值（忽略第一行與第一列的標題）
    """
    order_sheet = pd.read_excel(file_path, sheet_name='Order', header=None).iloc[1:, 1:].reset_index(drop=True)
    raw_pod_sheet = pd.read_excel(file_path, sheet_name='Pod', header=None).iloc[1:, 1:].reset_index(drop=True)

    # 將欄位名稱全部轉成 int（或依照數值順序）
    raw_pod_sheet.columns = raw_pod_sheet.columns.astype(int)
    pod_supply = {
        pid: {itm: val for itm, val in row.to_dict().items() if val > 0}
        for pid, row in raw_pod_sheet.iterrows()
    }
    return order_sheet, pod_supply

def get_pod_coverage_fast(needed_items, pod_data):
    """
    計算 coverage, 其中 pod_data 為 {item: qty, ...} 的 dict。
    """
    coverage = 0
    for item, need_qty in needed_items.items():
        if item in pod_data:
            coverage += min(need_qty, pod_data[item])
    return coverage

def update_items_and_pod_fast(needed_items, pod_data):
    """
    使用該 Pod 後，扣減該 Pod 的庫存 (pod_data) 與 needed_items。
    """
    for item in list(needed_items.keys()):
        if item in pod_data:
            used = min(needed_items[item], pod_data[item])
            needed_items[item] -= used
            pod_data[item] -= used
            if pod_data[item] <= 0:
                del pod_data[item]
            if needed_items[item] <= 0:
                del needed_items[item]'''

##############################
# 2) GA 主流程
##############################
def genetic_algorithm_for_rack_assignment(file_path, population_size=30, generations=50, crossover_rate=0.8, mutation_rate=0.2, agv_count=2, strategy="nearest"):
    # === 初始化階段 ===
    order_sheet, pod_supply = load_data(file_path)
    ss_xw, ss_yw, ss_xn, ss_yn, ps_n = 4, 2, 2, 2, 1
    pod_cnt = len(pod_supply)
    layout = Layout(
        storage_station_x_width=ss_xw,
        storage_station_y_width=ss_yw,
        storage_station_x_num=ss_xn,
        storage_station_y_num=ss_yn,
        picking_station_number=ps_n,
        pod_count=pod_cnt
    )

    population = init_population(file_path, population_size, layout, agv_count=agv_count)
    g_best = None

    for gen in range(1, generations + 1):
        print(f"\n=== Generation {gen}/{generations} ===")

        # 1️⃣ 計算所有個體的低細緻度適應值
        for ind in population:
            evaluate_fitness_low_fidelity(ind, file_path, layout)

        # 2️⃣ MO²TOS 選擇進入高細緻度模擬的個體
        selected_for_high_fidelity = mo2tos_selection(population)

        # 3️⃣ 執行高細緻度模擬
        for ind in selected_for_high_fidelity:
            layout_clone = copy.deepcopy(layout)
            evaluate_fitness_high_fidelity(ind, file_path, agv_count, layout=layout_clone, strategy=strategy)

        # 4️⃣ 更新全域最佳解 g_best
        best_in_gen = min(selected_for_high_fidelity, key=lambda x: x['fitness'], default=None)
        if g_best is None or (best_in_gen and best_in_gen['fitness'] < g_best['fitness']):
            g_best = copy.deepcopy(best_in_gen)
            print(f"🔹 更新 g_best: Fitness = {g_best['fitness']}")

        # 5️⃣ 判斷是否提前終止（可擴充收斂條件）
        #if g_best and g_best['fitness'] <= 0:
            #print("🎯 提前收斂，找到最佳解")
            #break

        # 6️⃣ GA 選擇、交配、突變
        selected = selection_tournament(population, k=2)
        offspring = []
        for i in range(0, len(selected), 2):
            p1 = selected[i]
            p2 = selected[i + 1] if i + 1 < len(selected) else selected[0]
            c1, c2 = copy.deepcopy(p1), copy.deepcopy(p2)

            if random.random() < crossover_rate:
                c1['chromosome'], c2['chromosome'] = single_point_crossover(p1['chromosome'], p2['chromosome'])
            if random.random() < mutation_rate:
                mutate_bit(c1['chromosome'])
            if random.random() < mutation_rate:
                mutate_bit(c2['chromosome'])

            validate_and_repair(c1['chromosome'], file_path)
            validate_and_repair(c2['chromosome'], file_path)

            offspring.extend([c1, c2])

        # 7️⃣ 對新一代個體進行低細緻度評估
        for ind in offspring:
            evaluate_fitness_low_fidelity(ind, file_path, layout)

        # 8️⃣ 合併族群並保留前 population_size 名
        population = sorted(population + offspring, key=lambda x: x['low_fidelity_fitness'])[:population_size]

    print(f"\n=== 最終 g_best ===\nFitness: {g_best['fitness']}\nChromosome: {g_best['chromosome']}")
    return g_best


'''def genetic_algorithm_for_rack_assignment(file_path, 
                                          population_size=30, generations=50,
                                          crossover_rate=0.8, mutation_rate=0.2, agv_count=2):
    population = init_population(file_path, population_size, agv_count=agv_count)
    best_sol = min(population, key=lambda x: x['fitness'])

    for gen in range(1, generations+1):
        print(f"\n=== Generation {gen}/{generations} ===")
        print("\n🔹 初始族群:")
        for idx, ind in enumerate(population):
            print(f"  🧬 個體 {idx}: Pods Sequence = {ind['chromosome']}, Fitness = {ind['fitness']}")


        selected = selection_tournament(population, k=2)
        offspring = []
        for i in range(0, len(selected), 2):
            p1 = selected[i]
            p2 = selected[i+1] if i+1 < len(selected) else selected[0]

            c1 = copy.deepcopy(p1)
            c2 = copy.deepcopy(p2)
            if random.random() < crossover_rate:
                c1['chromosome'], c2['chromosome'] = single_point_crossover(p1['chromosome'], p2['chromosome'])
            if random.random() < mutation_rate:
                mutate_bit(c1['chromosome'])
            if random.random() < mutation_rate:
                mutate_bit(c2['chromosome'])

            validate_and_repair(c1['chromosome'], file_path)
            validate_and_repair(c2['chromosome'], file_path)

            evaluate_fitness(c1, file_path, agv_count=agv_count)
            evaluate_fitness(c2, file_path, agv_count=agv_count)

            offspring.append(c1)
            offspring.append(c2)

        combined = population + offspring
        combined.sort(key=lambda x: x['fitness'])
        population = combined[:population_size]

        print("\n🔹 交配與突變後的族群:")
        for idx, ind in enumerate(population):
            print(f"  🧬 個體 {idx}: Pods Sequence = {ind['chromosome']}, Fitness = {ind['fitness']}")


        if population[0]['fitness'] < best_sol['fitness']:
            best_sol = copy.deepcopy(population[0])

        print(f"Best fitness in gen{gen}: {best_sol['fitness']}")

    return best_sol'''

def init_population(file_path, population_size, layout, agv_count=2):
    """
    初始化族群：
    - 每個個體皆為可行解（經過修復）
    - 預先計算低細緻度適應值，便於初步篩選
    """
    population = []
    for i in range(population_size):
        order_sheet, pod_supply = load_data(file_path)
        chrom = random_chromosome(order_sheet, pod_supply)
        validate_and_repair(chrom, file_path)

        individual = {
            'chromosome': chrom,
            'fitness': float('inf'),             # 高細緻度適應值
            'low_fidelity_fitness': float('inf'),# 低細緻度適應值
            'exec_time': 0.0
        }

        evaluate_fitness_low_fidelity(individual, file_path, layout)
        population.append(individual)

        #print(f"  🧬 初始個體 {i+1}: Low-Fidelity = {individual['low_fidelity_fitness']}, 染色體 = {chrom}")

    return population

def selection_tournament(population, k=2):
    """
    錦標賽選擇：
    - 從隨機挑選的 k 個體中選出最佳者
    - 基於低細緻度適應值進行快速選擇
    """
    selected = []
    for _ in range(len(population)):
        candidates = random.sample(population, k)
        best = min(candidates, key=lambda x: x['low_fidelity_fitness'])
        selected.append(copy.deepcopy(best))
    return selected

def single_point_crossover(parent1, parent2):
    """
    單點交配：
    - 對兩個批次列表進行交叉
    - 若批次數不足，不進行交配
    """
    if len(parent1) < 2 or len(parent2) < 2:
        return parent1, parent2

    cut_point = random.randint(1, min(len(parent1), len(parent2)) - 1)
    child1 = parent1[:cut_point] + parent2[cut_point:]
    child2 = parent2[:cut_point] + parent1[cut_point:]

    return child1, child2

def mutate_bit(chromosome):
    """
    基因突變：
    - 隨機刪除某個批次中的一個 Pod
    - 避免空染色體或空批次
    """
    if not chromosome:
        return

    batch_idx = random.randint(0, len(chromosome) - 1)
    if chromosome[batch_idx]:
        del_idx = random.randrange(len(chromosome[batch_idx]))
        removed = chromosome[batch_idx].pop(del_idx)
        #print(f"🔧 突變：批次 {batch_idx} 移除 Pod {removed}")

##############################
# 3) 隨機產生染色體 & validate & repair
##############################
def random_chromosome(order_sheet, pod_supply):
    """
    生成隨機的染色體，每個批次 (2 個訂單) 分配不同的儲存站順序來滿足訂單需求。
    - 保證 Pod 可以滿足訂單
    - 確保每個個體有不同的 Pod 順序
    """
    chrom = []
    batch_count = (len(order_sheet) + 1) // 2
    all_pod_ids = list(pod_supply.keys())  # 可用的 Pod ID
    
    for batch_idx in range(batch_count):
        needed_items = combine_orders_batch(order_sheet, batch_idx * 2)
        batch_pods = []
        
        # **確保 Pod 排序是隨機的**
        candidate_pods = list(pod_supply.keys())
        random.shuffle(candidate_pods)

        while needed_items:
            if not candidate_pods:
                print(f"⚠️ 批次 {batch_idx} 可能無法滿足訂單，嘗試補充 Pod...")
                break

            # **隨機選擇 coverage > 0 的 Pod**
            valid_pods = [pid for pid in candidate_pods if get_pod_coverage_fast(needed_items, pod_supply[pid]) > 0]
            
            if not valid_pods:
                break  # **沒有可行的 Pod 了**

            selected_pod = random.choice(valid_pods)  # **確保不總是選最大 coverage**
            batch_pods.append(selected_pod)
            update_items_and_pod_fast(needed_items, pod_supply[selected_pod])

        chrom.append(batch_pods)

    return chrom

def validate_and_repair(chrom, file_path):
    """
    修正染色體，確保：
    1. 若前一個批次最後使用的儲存站仍有可用物料，則優先使用
    2. 只有當工作站沒有可用儲存站時，才指派新的儲存站
    3. **新增隨機選擇機制** 來提高解的多樣性
    """
    order_sheet, pod_supply = load_data(file_path)  # **重新讀取 Excel 原始資料**
    idx = 0
    new_chrom = []
    last_pod = None  # **紀錄前一個批次最後使用的儲存站**

    for batch_idx, batch_pods in enumerate(chrom):
        needed_items = combine_orders_batch(order_sheet, idx)
        idx += 2
        feasible_pods = []

        # **Step 1: 若前一個批次的最後儲存站還有可用物料，則優先使用**
        if last_pod and last_pod in pod_supply:
            coverage = get_pod_coverage_fast(needed_items, pod_supply[last_pod])
            if coverage > 0:
                feasible_pods.append(last_pod)
                update_items_and_pod_fast(needed_items, pod_supply[last_pod])

        # **Step 2: 若仍有未滿足需求，則隨機選擇新的儲存站**
        while needed_items:
            # **取得所有可行的 Pod**
            candidate_pods = [pid for pid, supply in pod_supply.items() if get_pod_coverage_fast(needed_items, supply) > 0]

            if not candidate_pods:
                print(f"❌ 批次 {batch_idx} 無法滿足訂單，請檢查 Pod 配置！")
                break
            
            # **新增：隨機選擇 Pod，而不是固定最大 coverage**
            selected_pod = random.choice(candidate_pods)

            # **可選：偶爾使用 coverage 最大的 Pod (50% 機率)**
            if random.random() < 0.5:
                selected_pod = max(candidate_pods, key=lambda pid: get_pod_coverage_fast(needed_items, pod_supply[pid]))

            feasible_pods.append(selected_pod)
            update_items_and_pod_fast(needed_items, pod_supply[selected_pod])
            last_pod = selected_pod  # **更新最後使用的儲存站**

        new_chrom.append(feasible_pods)

    chrom[:] = new_chrom  # **更新染色體**


##############################
# 4) GA selection / crossover / mutation
##############################


def single_point_crossover(c1, c2):
    size1 = len(c1)
    size2 = len(c2)
    if size1 < 2 or size2 < 2:
        return c1, c2
    min_len = min(size1, size2)
    cut = random.randint(1, min_len-1)
    child1 = c1[:cut] + c2[cut:]
    child2 = c2[:cut] + c1[cut:]
    return child1, child2

def mutate_bit(chrom):
    if not chrom:
        return
    batch_idx = random.randint(0, len(chrom)-1)
    if chrom[batch_idx]:
        del_idx = random.randrange(len(chrom[batch_idx]))
        del chrom[batch_idx][del_idx]

##############################
# 5) Evaluate
##############################

# ----------------------------------------------------
def manhattan_distance(pos1, pos2):
    """計算曼哈頓距離"""
    return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

def compute_distance_matrices(layout):
    """計算所有儲存站與揀貨站之間的曼哈頓距離矩陣"""
    storage_positions = {i: (st.x_position, st.y_position) for i, st in enumerate(layout.storage_station_list)}
    picking_positions = {i: (ps.x_position, ps.y_position) for i, ps in enumerate(layout.picking_station_list)}

    storage_to_picking = {
        sid: {pid: manhattan_distance(pos, picking_positions[pid]) for pid in picking_positions}
        for sid, pos in storage_positions.items()
    }

    storage_to_storage = {
        sid1: {sid2: manhattan_distance(pos1, pos2) for sid2, pos2 in storage_positions.items() if sid1 != sid2}
        for sid1, pos1 in storage_positions.items()
    }

    return storage_to_picking, storage_to_storage

def evaluate_fitness_low_fidelity(ind, file_path, layout):
    """
    低細緻度適應值計算：
    - 使用靜態曼哈頓距離快速估算
    - 僅用於 MO²TOS 選擇依據
    """
    storage_to_picking, storage_to_storage = compute_distance_matrices(layout)
    total_distance = 0

    for batch in ind['chromosome']:
        if not batch:
            continue
        last_pod = None
        for pod_id in batch:
            total_distance += storage_to_picking.get(pod_id, {}).get(0, 0)  # 假設揀貨站為 ID 0
            if last_pod is not None:
                total_distance += storage_to_storage.get(last_pod, {}).get(pod_id, 0)
            last_pod = pod_id

    ind['low_fidelity_fitness'] = total_distance

def evaluate_fitness_high_fidelity(ind, file_path, agv_count=2, layout=None, strategy="nearest"):
    """
    高細緻度適應值計算：
    - 動態模擬完整流程
    - DQN 策略會同時進行經驗收集與訓練
    """
    try:
        if any(len(batch) == 0 for batch in ind['chromosome']):
            ind['fitness'] = float('inf')
            return
        if layout is None:
            ss_xw, ss_yw, ss_xn, ss_yn, ps_n = 4, 2, 3, 3, 1
            order_sheet, pod_supply = load_data(file_path)
            pod_cnt = len(pod_supply)
            layout = Layout(ss_xw, ss_yw, ss_xn, ss_yn, ps_n, pod_count=pod_cnt)
            for pod in layout.pod_list:
                pod.content = pod_supply.get(pod.pod_id, {})
        layout.task_list = layout.convert_solution_to_tasks(ind['chromosome'])
        layout.agent_training_data = []
        explorers = [Explorer(layout, f"veh{i+1}", reposition_strategy=strategy, dqn_agent=agent if strategy=="dqn" else None) for i in range(agv_count)]
        layout.explorer_group = explorers
        sim_scene = Scene(layout, explorers, render=False)
        sim_scene.eval_mode = True
        fitness_value, makespan = sim_scene.simulate_full()
        total_tasks = len(layout.task_list)
        max_reasonable_distance = max(20000, total_tasks * 15)
        is_valid_episode = (fitness_value > 0) and (fitness_value < max_reasonable_distance)
        if strategy == "dqn":
            agent.log_training_distance(fitness_value, total_tasks=total_tasks if is_valid_episode else None)
        if strategy == "dqn" and not use_trained_model:
            for s, a, r, s_, d in layout.agent_training_data:
                if is_valid_episode:
                    agent.store_transition(s, a, r, s_, d)
            if is_valid_episode and agent.memory.tree.n_entries > agent.start_training_info_number:
                agent.update_network()
        ind['fitness'] = fitness_value if is_valid_episode else float('inf')
        ind['makespan'] = makespan
    except Exception as e:
        print(f"❌ 高細緻度模擬錯誤: {e}")
        ind['fitness'] = float('inf')


##############################
# 4) MO²TOS 分群選擇高細緻度個體
##############################
def mo2tos_selection(population):
    """MO²TOS 分群選擇進行高細緻度模擬的個體"""
    sorted_pop = sorted(population, key=lambda x: x['low_fidelity_fitness'])

    top_30_percent = sorted_pop[:max(1, int(len(population) * 0.3))]
    high_var_20_percent = sorted(sorted_pop, key=lambda x: abs(x['low_fidelity_fitness'] - sorted_pop[0]['low_fidelity_fitness']), reverse=True)[:max(1, int(len(population) * 0.2))]

    # ⚡ 正確合併，避免 dict 無法 hash
    selected = []
    seen = set()

    for ind in top_30_percent + high_var_20_percent:
        ind_id = id(ind)
        if ind_id not in seen:
            selected.append(ind)
            seen.add(ind_id)

    return selected

##############################
# 6) 其餘輔助函式
##############################

def combine_orders_all(order_sheet):
    needed_all = {}
    idx = 0
    while idx < len(order_sheet):
        row = order_sheet.iloc[idx:idx+2].sum(axis=0).to_dict()
        for k, v in row.items():
            if v > 0:
                needed_all[int(k)] = needed_all.get(int(k), 0) + v
        idx += 2
    return needed_all

def combine_orders_batch(order_sheet, idx):
    """將兩筆訂單合併成一個批次的需求"""
    needed_items = {}
    batch_orders = order_sheet.iloc[idx:idx+2].sum(axis=0).to_dict()
    for item, qty in batch_orders.items():
        if qty > 0:
            needed_items[int(item)] = qty
    return needed_items

'''def combine_orders_batch(order_sheet, idx):
    needed_items = {}
    sub_df = order_sheet.iloc[idx:idx+2]
    row_sum = sub_df.sum(axis=0).to_dict()
    for k, v in row_sum.items():
        if v > 0:
            needed_items[int(k)] = v
    return needed_items'''

def get_pod_coverage_for_repair(needed_items, test_supply, pid):
    if pid not in test_supply:
        return 0
    return get_pod_coverage_fast(needed_items, test_supply[pid])

def update_items_and_pod_for_repair(needed_items, test_supply, pid):
    if pid in test_supply:
        update_items_and_pod_fast(needed_items, test_supply[pid])

##############################
# 7) 封裝 GA 主流程為一個函式供 main.py 呼叫
##############################
def run_ga(file_path, population_size=30, generations=50, crossover_rate=0.8, mutation_rate=0.2, agv_count=3, strategy="nearest"):
    start_time = time.time()
    best_solution = genetic_algorithm_for_rack_assignment(
        file_path=file_path,
        population_size=population_size,
        generations=generations,
        crossover_rate=crossover_rate,
        mutation_rate=mutation_rate,
        agv_count=agv_count,
        strategy=strategy
    )
    total_time = time.time() - start_time

    print("\n=== GA 最佳解 ===")
    print(f"最終適應值 (動態模擬結果): {best_solution['fitness']}")
    print(f"Pods Sequence: {best_solution['chromosome']}")
    print(f"總執行時間(秒): {total_time:.2f}")

    # === 儲存 DQN 模型 ===
    if strategy == "dqn" and not use_trained_model:
        torch.save(agent.policy_network.state_dict(), "dqn_policy_model.pth")
        print(f" DQN 模型已儲存: dqn_policy_model.pth")

    # === 視覺化訓練過程 ===
    visualize_training_metrics(agent)

    return best_solution

def visualize_training_metrics(agent):
    if agent.loss_value:
        plt.figure()
        smoothed_loss = agent.smooth_curve(agent.loss_value, factor=0.95)
        plt.plot(smoothed_loss)
        plt.title("DQN Training Loss")
        plt.xlabel("Steps")
        plt.ylabel("Loss")
        plt.savefig("dqn_loss_curve.png")
        plt.close()

    if agent.training_rewards:
        plt.figure()
        smoothed_rewards = agent.smooth_curve(agent.training_rewards, factor=0.95)
        plt.plot(smoothed_rewards)
        plt.title("DQN Reward Trend")
        plt.xlabel("Steps")
        plt.ylabel("Reward")
        plt.savefig("reward_trend.png")
        plt.close()

    if agent.action_count and sum(agent.action_count.values()) > 0:
        plt.figure(figsize=(6, 4))
        actions = ['Nearest', 'Cache', 'Utility', 'No Change']
        counts = [agent.action_count.get(i, 0) for i in range(4)]
        plt.bar(actions, counts)
        plt.title("DQN Action Usage Distribution")
        plt.savefig("action_distribution.png")
        plt.close()

    if agent.distance_log:
        plt.figure()
        plt.plot(agent.distance_log)
        plt.title("Transport Distance Trend (DQN Training)")
        plt.xlabel("Episode (Generation)")
        plt.ylabel("Total Transport Distance")
        plt.savefig("transport_distance_trend.png")
        plt.close()

def print_storage_to_picking_distances(layout):
    """列印所有儲存站到工作站的距離 (曼哈頓距離)"""
    storage_to_picking, _ = compute_distance_matrices(layout)
    print("\n 儲存站 >> 工作站 的曼哈頓距離 (Storage to Picking):")
    for sid, dist_dict in storage_to_picking.items():
        for pid, dist in dist_dict.items():
            print(f"  - 儲存站 {sid} → 工作站 {pid}: 距離 = {dist}")
##############################
# 8) 主程式區塊
##############################

if __name__ == "__main__":
    # === 基本參數設定 ===
    file_path = r"C:\Users\user\Desktop\訓練資料整理\dataset195\exp1_O3K195k97_P12_r10.xlsx"   # ⚠️ 請確認路徑與檔名正確
    strategy = "none"   # 可選: "nearest", "cache", "utility", "dqn", "none"

    # GA 參數
    population_size = 30
    generations = 50
    crossover_rate = 0.8
    mutation_rate = 0.2
    agv_count = 4

    print(f"\n 啟動多細緻度 GA 優化流程 | 策略: {strategy.upper()} | 檔案: {file_path}")
    best_solution = run_ga(
        file_path=file_path,
        population_size=population_size,
        generations=generations,
        crossover_rate=crossover_rate,
        mutation_rate=mutation_rate,
        agv_count=agv_count,
        strategy=strategy
    )

    #print("\n 最佳解完成！")

    '''agv_range = range(1, 9)  # 1~8 台 AGV
    makespan_list = []

    for agv_count in agv_range:
        print(f"=== 測試 AGV 數量: {agv_count} ===")
        best_solution = run_ga(
            file_path=file_path,
            population_size=population_size,
            generations=generations,
            crossover_rate=crossover_rate,
            mutation_rate=mutation_rate,
            agv_count=agv_count,
            strategy=strategy
        )
        makespan_list.append(best_solution.get('makespan', None))
    print(makespan_list)
    plt.figure()
    plt.plot(list(agv_range), makespan_list, marker='o')
    plt.xlabel("AGV數量")
    plt.ylabel("訂單總完成時間（makespan）")
    plt.title("AGV數量對Makespan的影響")
    plt.savefig("makespan_vs_agv.png")
    plt.show()'''
